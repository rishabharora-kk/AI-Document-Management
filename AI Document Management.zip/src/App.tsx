import { Authenticated, Unauthenticated, useQuery, useMutation, useAction } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster, toast } from "sonner";
import { useState, useRef } from "react";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-xl font-semibold accent-text">AI Document Manager</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 p-8">
        <div className="max-w-6xl mx-auto">
          <Content />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const documents = useQuery(api.documents.listDocuments);
  const generateUploadUrl = useMutation(api.documents.generateUploadUrl);
  const saveDocument = useMutation(api.documents.saveDocument);
  const classifyDocument = useAction(api.documents.classifyDocument);
  const requestAccess = useMutation(api.documents.requestAccess);

  const [uploading, setUploading] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  async function handleFileUpload(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      setUploading(true);
      
      // Get upload URL
      const uploadUrl = await generateUploadUrl();
      
      // Upload file
      const result = await fetch(uploadUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      const { storageId } = await result.json();

      // Read file content for classification
      const text = await file.text();
      const classification = await classifyDocument({
        name: file.name,
        content: text.slice(0, 1000), // Send first 1000 chars for classification
      });

      // Save document metadata
      await saveDocument({
        name: file.name,
        contentType: file.type,
        storageId,
        ...classification,
      });

      toast.success("Document uploaded successfully!");
      if (fileInput.current) fileInput.current.value = "";
    } catch (error) {
      toast.error("Upload failed: " + (error as Error).message);
    } finally {
      setUploading(false);
    }
  }

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold accent-text mb-4">AI Document Management</h1>
        <Authenticated>
          <p className="text-xl text-slate-600">Welcome, {loggedInUser?.email}!</p>
        </Authenticated>
        <Unauthenticated>
          <p className="text-xl text-slate-600">Sign in to manage documents</p>
        </Unauthenticated>
      </div>

      <Unauthenticated>
        <SignInForm />
      </Unauthenticated>

      <Authenticated>
        <div className="flex flex-col gap-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-4">Upload Document</h3>
            <input
              type="file"
              ref={fileInput}
              onChange={handleFileUpload}
              disabled={uploading}
              className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
            />
            {uploading && <p className="mt-2 text-sm text-slate-600">Uploading and classifying...</p>}
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="text-lg font-semibold mb-4">Your Documents</h3>
            {documents?.length === 0 ? (
              <p className="text-slate-600">No documents yet. Upload your first document above!</p>
            ) : (
              <div className="grid gap-4">
                {documents?.map((doc) => (
                  <div key={doc._id} className="border rounded p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium">{doc.name}</h4>
                        <p className="text-sm text-slate-600 mt-1">{doc.summary}</p>
                        <div className="flex gap-2 mt-2">
                          {doc.tags.map((tag, i) => (
                            <span key={i} className="bg-slate-100 text-slate-700 text-xs px-2 py-1 rounded">
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded ${
                        doc.classification === "Confidential" ? "bg-red-100 text-red-700" :
                        doc.classification === "Internal" ? "bg-yellow-100 text-yellow-700" :
                        "bg-green-100 text-green-700"
                      }`}>
                        {doc.classification}
                      </span>
                    </div>
                    <div className="mt-4 flex gap-2">
                      {doc.url && (
                        <a
                          href={doc.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm text-indigo-600 hover:text-indigo-800"
                        >
                          Download
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </Authenticated>
    </div>
  );
}
