import { v } from "convex/values";
import { mutation, query, action } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import OpenAI from "openai";

const openai = new OpenAI({
  baseURL: process.env.CONVEX_OPENAI_BASE_URL,
  apiKey: process.env.CONVEX_OPENAI_API_KEY,
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    return await ctx.storage.generateUploadUrl();
  },
});

export const classifyDocument = action({
  args: {
    name: v.string(),
    content: v.string(),
  },
  handler: async (ctx, args) => {
    const response = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [
        {
          role: "system",
          content: "You are a document classifier. Analyze the document and provide: 1) A classification (Confidential, Internal, or Public), 2) A brief summary, 3) Relevant tags. Format as JSON.",
        },
        {
          role: "user",
          content: `Document Name: ${args.name}\nContent: ${args.content}`,
        },
      ],
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      classification: result.classification || "Internal",
      summary: result.summary || "",
      tags: result.tags || [],
    };
  },
});

export const saveDocument = mutation({
  args: {
    name: v.string(),
    contentType: v.string(),
    storageId: v.id("_storage"),
    classification: v.string(),
    summary: v.string(),
    tags: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.insert("documents", {
      ...args,
      ownerId: userId,
      accessList: [userId],
    });
  },
});

export const listDocuments = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const docs = await ctx.db
      .query("documents")
      .withIndex("by_access")
      .filter((q) => q.eq(q.field("accessList"), [userId]))
      .collect();

    return await Promise.all(
      docs.map(async (doc) => ({
        ...doc,
        url: await ctx.storage.getUrl(doc.storageId),
      }))
    );
  },
});

export const requestAccess = mutation({
  args: {
    documentId: v.id("documents"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.insert("accessRequests", {
      documentId: args.documentId,
      requesterId: userId,
      status: "pending",
    });
  },
});

export const approveAccess = mutation({
  args: {
    requestId: v.id("accessRequests"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const request = await ctx.db.get(args.requestId);
    if (!request) throw new Error("Request not found");

    const document = await ctx.db.get(request.documentId);
    if (!document) throw new Error("Document not found");
    if (document.ownerId !== userId) throw new Error("Not authorized");

    await ctx.db.patch(request.documentId, {
      accessList: [...document.accessList, request.requesterId],
    });

    await ctx.db.patch(args.requestId, {
      status: "approved",
    });
  },
});
