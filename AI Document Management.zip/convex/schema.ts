import { defineSchema, defineTable } from "convex/server";
import { authTables } from "@convex-dev/auth/server";
import { v } from "convex/values";

const applicationTables = {
  documents: defineTable({
    name: v.string(),
    contentType: v.string(),
    storageId: v.id("_storage"),
    classification: v.string(),
    ownerId: v.id("users"),
    accessList: v.array(v.id("users")),
    summary: v.string(),
    tags: v.array(v.string()),
  })
    .index("by_owner", ["ownerId"])
    .index("by_access", ["accessList"]),
  
  accessRequests: defineTable({
    documentId: v.id("documents"),
    requesterId: v.id("users"),
    status: v.union(v.literal("pending"), v.literal("approved"), v.literal("rejected")),
  }).index("by_requester", ["requesterId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
